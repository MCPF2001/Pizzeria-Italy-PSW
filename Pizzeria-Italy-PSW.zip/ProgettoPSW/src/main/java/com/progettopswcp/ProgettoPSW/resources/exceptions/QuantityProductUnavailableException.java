package com.progettopswcp.ProgettoPSW.resources.exceptions;

public class QuantityProductUnavailableException extends RuntimeException {
  public QuantityProductUnavailableException(String s) {
    super(s);
  }
  }
