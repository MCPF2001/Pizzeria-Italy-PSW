package com.progettopswcp.ProgettoPSW.resources.exceptions;

public class DateWrongRangeException extends RuntimeException {
  public DateWrongRangeException(String s){super(s);}

}
