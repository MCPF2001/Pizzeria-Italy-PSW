package com.progettopswcp.ProgettoPSW.resources.exceptions;

public class MailUserAlreadyExistsException extends RuntimeException {
    public MailUserAlreadyExistsException() {
    }
}
