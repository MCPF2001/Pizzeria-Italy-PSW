package com.progettopswcp.ProgettoPSW;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProgettoPswApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgettoPswApplication.class, args);
	}

}
