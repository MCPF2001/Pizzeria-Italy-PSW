package com.progettopswcp.ProgettoPSW.resources.exceptions;


public class BarCodeAlreadyExistException extends Exception {

    public BarCodeAlreadyExistException() {}

}
