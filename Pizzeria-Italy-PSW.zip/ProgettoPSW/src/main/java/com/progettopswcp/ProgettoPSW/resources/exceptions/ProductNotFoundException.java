package com.progettopswcp.ProgettoPSW.resources.exceptions;

    public class ProductNotFoundException extends RuntimeException {

        public ProductNotFoundException(String s) {
        super(s);
    }

}