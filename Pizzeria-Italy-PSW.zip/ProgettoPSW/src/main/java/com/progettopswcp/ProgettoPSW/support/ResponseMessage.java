package com.progettopswcp.ProgettoPSW.support;

public class ResponseMessage {
    private String message;


    public ResponseMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }


}
