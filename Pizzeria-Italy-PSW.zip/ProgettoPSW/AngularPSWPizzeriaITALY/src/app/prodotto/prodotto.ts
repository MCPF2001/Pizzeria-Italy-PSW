export interface prodotto {
  id: number;
  nome: string;
  prezzo: number;
  quantita: boolean;
  TipoProdotto: string;
  disponibilita: boolean;
}
